# discord-moderation-bot
This is a **moderation bot** for Discord.
You are free to use this template to make your own bots.

## How to contribute?
You can contribute by following these steps.
- 1- Fork this project.
- 2- Make you're own changes.
- 3- Make a pull request.
- 4- Wait for approval.

## Contact
Also you can contact me from:
- Discord: okunamayanad#5406
- E-mail: okunamayanad+aboutdiscordmodbot@gmail.com
